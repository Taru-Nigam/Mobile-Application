namespace EcoTracker.Pages;
using EcoTracker.Models;
using Microsoft.Maui.Controls;

public partial class GoalCompletedPage : ContentPage
{
    private Goal _completedGoal;

    public GoalCompletedPage(Goal completedGoal)
    {
        InitializeComponent();
        _completedGoal = completedGoal;
        LoadGoalMetrics();
    }

    private void LoadGoalMetrics()
    {
        // Set the metrics text for the completed goal
        MetricsLabel.Text = $"Metrics:\nDistance Traveled: {_completedGoal.Distance} KMs\n" +
                            $"Energy Consumed: {_completedGoal.Energy} kWh\n" +
                            $"Waste Produced: {_completedGoal.Waste} Lbs";
    }

    private async void OnTakePictureClicked(object sender, EventArgs e)
    {
        try
        {
            // Request permissions for camera and storage
            var status = await Permissions.RequestAsync<Permissions.Camera>();
            if (status != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission Denied", "Camera permission is required to take a picture.", "OK");
                return;
            }

            // Optionally, request storage permission if you want to access the gallery
            status = await Permissions.RequestAsync<Permissions.StorageRead>();
            if (status != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission Denied", "Storage permission is required to access the gallery.", "OK");
                return;
            }

            // Prompt the user to take a picture or select from the gallery
            var action = await DisplayActionSheet("Choose an option", "Cancel", null, "Take a Picture", "Select from Gallery");

            if (action == "Take a Picture")
            {
                var photo = await MediaPicker.CapturePhotoAsync();
                if (photo != null)
                {
                    var stream = await photo.OpenReadAsync();
                    // Save the photo stream to your app's history or database
                    // You can use a method similar to SavePhoto(stream);
                }
            }
            else if (action == "Select from Gallery")
            {
                var photo = await MediaPicker.PickPhotoAsync();
                if (photo != null)
                {
                    var stream = await photo.OpenReadAsync();
                    // Save the photo stream to your app's history or database
                    // You can use a method similar to SavePhoto(stream);
                }
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");
            // Navigate back to the EditGoals page
            await Navigation.PopAsync();
        }
    }
}