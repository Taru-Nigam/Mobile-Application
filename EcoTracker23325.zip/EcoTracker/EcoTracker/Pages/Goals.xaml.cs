using System;
using System.Collections.Generic;
using EcoTracker.Models;
using Microsoft.Maui.Controls;

namespace EcoTracker.Pages
{
    public partial class Goals : ContentPage
    {
        private GoalsDatabase goalsDatabase;
        private List<Goal> goals;

        public Goals()
        {
            InitializeComponent();
            goalsDatabase = new GoalsDatabase();
            LoadGoals();
        }

        private void LoadGoals()
        {
            goals = goalsDatabase.GetGoals();
            foreach (var goal in goals)
            {
                if (goal.IsCompleted)
                {
                    // Optionally, grey out the completed goals
                    goal.Description += " (Completed)"; // Or use a property to indicate completion
                }
            }
            GoalsListView.ItemsSource = goals;
        }

        private void OnAddGoalClicked(object sender, EventArgs e)
        {
            // Get the goal description and target date
            string goalDescription = GoalDescriptionEntry.Text;
            DateTime targetDate = TargetDatePicker.Date;

            // Validate input
            if (string.IsNullOrWhiteSpace(goalDescription))
            {
                DisplayAlert("Error", "Please enter a goal description.", "OK");
                return;
            }

            // Create a new goal object
            Goal newGoal = new Goal
            {
                Description = goalDescription,
                TargetDate = targetDate
            };

            // Add the goal to the database
            goalsDatabase.AddGoal(newGoal);

            // Refresh the ListView
            LoadGoals();

            // Optionally, display a success message
            DisplayAlert("Success", "Goal added successfully!", "OK");

            // Clear the input fields
            GoalDescriptionEntry.Text = string.Empty;
            TargetDatePicker.Date = DateTime.Now;
        }
        private async void OnGoalSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null) return;

            var selectedGoal = (Goal)e.SelectedItem;
            await Navigation.PushAsync(new EditGoals(selectedGoal));

            // Clear selection
            GoalsListView.SelectedItem = null;
        }
    }
}