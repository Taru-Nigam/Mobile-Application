﻿using Microsoft.Extensions.Logging;
using Microsoft.Maui.Handlers;

namespace EcoTracker
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });
            builder
                .UseMauiApp<App>()
                .ConfigureMauiHandlers(handlers => 
                {
                handlers.AddHandler<Border, BorderHandler>();
                });

#if DEBUG
            builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}
