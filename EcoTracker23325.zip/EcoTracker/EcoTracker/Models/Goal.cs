﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoTracker.Models
{
    public class Goal
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public string AdditionalDetails { get; set; }
        public DateTime TargetDate { get; set; }
        public int DaysRemaining => (TargetDate - DateTime.Now).Days;
        public double Distance { get; set; }
        public double Energy { get; set; }
        public double Waste { get; set; }

        public bool IsCompleted { get; set; }
    }
}
