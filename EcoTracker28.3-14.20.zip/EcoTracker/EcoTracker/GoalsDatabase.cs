﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;
using EcoTracker.Models;

namespace EcoTracker
{
    public class GoalsDatabase
    {
        private readonly string dbPath;

        public GoalsDatabase()
        {
            dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "goals.db");
            CreateDatabase();
        }

        private void CreateDatabase()
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                CREATE TABLE IF NOT EXISTS Goals (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Description TEXT NOT NULL,
                    AdditionalDetails TEXT,
                    TargetDate TEXT NOT NULL,
                    IsCompleted INTEGER NOT NULL,
                    Distance REAL,
                    Energy REAL,
                    Waste REAL,
                    ImagePath TEXT
                )";
                command.ExecuteNonQuery();
            }
        }

        public void AddGoal(Goal goal)
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
               INSERT INTO Goals (Description, AdditionalDetails, TargetDate, IsCompleted, Distance, Energy, Waste, ImagePath)
                VALUES ($description, $additionalDetails, $targetDate, $isCompleted, $distance, $energy, $waste, $imagePath)";
                command.Parameters.AddWithValue("$description", goal.Description);
                command.Parameters.AddWithValue("$additionalDetails", (object)goal.AdditionalDetails ?? DBNull.Value); // Handle null
                command.Parameters.AddWithValue("$targetDate", goal.TargetDate.HasValue ? goal.TargetDate.Value.ToString("o") : (object)DBNull.Value); // Handle null
                command.Parameters.AddWithValue("$isCompleted", goal.IsCompleted);
                command.Parameters.AddWithValue("$distance", goal.Distance);
                command.Parameters.AddWithValue("$energy", goal.Energy);
                command.Parameters.AddWithValue("$waste", goal.Waste);
                command.Parameters.AddWithValue("$imagePath", (object)goal.ImagePath ?? DBNull.Value); // Handle null
                command.ExecuteNonQuery();
            }
        }

        public List<Goal> GetGoals()
        {
            var goals = new List<Goal>();
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT Id, Description, TargetDate FROM Goals";
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        goals.Add(new Goal
                        {
                            Id = reader.GetInt32(0),
                            Description = reader.GetString(1),
                            TargetDate = DateTime.Parse(reader.GetString(2))
                        });
                    }
                }
            }
            return goals;
        }

        public void UpdateGoal(Goal goal)
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                UPDATE Goals 
                    SET Description = $description,
                    AdditionalDetails = $additionalDetails,
                    TargetDate = $targetDate,
                    IsCompleted = $isCompleted,
                    Distance = $distance,
                    Energy = $energy,
                    Waste = $waste,
                    ImagePath = $imagePath
                WHERE Id = $id";
                command.Parameters.AddWithValue("$id", goal.Id);
                command.Parameters.AddWithValue("$description", goal.Description);
                command.Parameters.AddWithValue("$additionalDetails", (object)goal.AdditionalDetails ?? DBNull.Value); // Handle null
                command.Parameters.AddWithValue("$targetDate", goal.TargetDate.HasValue ? goal.TargetDate.Value.ToString("o") : (object)DBNull.Value); // Handle null
                command.Parameters.AddWithValue("$isCompleted", goal.IsCompleted);
                command.Parameters.AddWithValue("$distance", goal.Distance);
                command.Parameters.AddWithValue("$energy", goal.Energy);
                command.Parameters.AddWithValue("$waste", goal.Waste);
                command.Parameters.AddWithValue("$imagePath", (object)goal.ImagePath ?? DBNull.Value); // Handle null
                command.ExecuteNonQuery();
            }
        }

        public Goal GetGoalById(int id)
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT Id, Description, TargetDate FROM Goals WHERE Id = $id";
                command.Parameters.AddWithValue("$id", id);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Goal
                        {
                            Id = reader.GetInt32(0),
                            Description = reader.GetString(1),
                            TargetDate = DateTime.Parse(reader.GetString(2))
                        };
                    }
                }
            }
            return null;
        }
    }
}