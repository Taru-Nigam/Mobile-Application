using EcoTracker.Models;
using Microsoft.Maui.Controls;

namespace EcoTracker.Pages;

public partial class EditGoals : ContentPage
{
    private Goal _currentGoal;
    private GoalsDatabase _database = new GoalsDatabase();

    public EditGoals(Goal goal)
    {
        InitializeComponent();
        _currentGoal = goal;
        LoadGoalData();
    }

    private void LoadGoalData()
    {
        DescriptionEditor.Text = _currentGoal.Description ?? string.Empty; // Set to empty if null
        AdditionalDetailsEditor.Text = _currentGoal.AdditionalDetails ?? string.Empty; // Set to empty if null
        TargetDatePicker.Date = _currentGoal.TargetDate ?? DateTime.Now; // Default to now if null
    }

    private async void OnGoalAchievedClicked(object sender, EventArgs e)
    {
        // Mark the goal as completed in the database
        _currentGoal.IsCompleted = true; // Ensure this property exists in your Goal model
        _database.UpdateGoal(_currentGoal);

        // Navigate to the GoalCompletedPage with the completed goal
        await Navigation.PushAsync(new GoalCompletedPage(_currentGoal));
    }

    private async void OnSaveClicked(object sender, EventArgs e)
    {
        // Check if the selected date is in the past
        if (TargetDatePicker.Date < DateTime.Now)
        {
            await DisplayAlert("Invalid Date", "The selected date has already passed. Please choose a future date.", "OK");
            return; // Exit the method if the date is invalid
        }

        // Proceed with saving the goal if the date is valid
        _currentGoal.Description = DescriptionEditor.Text;
        _currentGoal.AdditionalDetails = AdditionalDetailsEditor.Text;
        _currentGoal.TargetDate = TargetDatePicker.Date;

        _database.UpdateGoal(_currentGoal);

        await DisplayAlert("Success", "Goal updated successfully!", "OK");
        await Navigation.PopAsync();
    }
}