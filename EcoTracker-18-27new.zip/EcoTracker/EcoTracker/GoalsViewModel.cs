using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EcoTracker.Models;
using System.Collections.ObjectModel;

namespace EcoTracker.ViewModels
{
    public partial class GoalsViewModel : ObservableObject
    {
        private readonly GoalsDatabase _goalsDatabase;

        public GoalsViewModel()
        {
            _goalsDatabase = new GoalsDatabase();
            LoadGoals();
        }

        [ObservableProperty]
        private ObservableCollection<Goal> _goals;

        public void LoadGoals()
        {
            var goalsList = _goalsDatabase.GetGoals();
            Goals = new ObservableCollection<Goal>(goalsList);
        }

        [RelayCommand]
        public void AddGoal(Goal newGoal)
        {
            _goalsDatabase.AddGoal(newGoal);
            LoadGoals();
        }

        [RelayCommand]
        public void UpdateGoal(Goal updatedGoal)
        {
            _goalsDatabase.UpdateGoal(updatedGoal);
            LoadGoals();
        }
    }
}