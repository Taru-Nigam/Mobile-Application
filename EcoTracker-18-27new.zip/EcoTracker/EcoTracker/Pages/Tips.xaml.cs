﻿using System.Collections.Generic;
using Microsoft.Maui;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Controls.Shapes;


namespace EcoTracker.Pages;

public partial class Tips : ContentPage
{
    private DatabaseHelper _databaseHelper;
    public Tips()
	{
		InitializeComponent();
        _databaseHelper = new DatabaseHelper();
        _databaseHelper.SeedDatabase(); // Call this only once to seed the database
        LoadRandomTips();
    }
    private void LoadRandomTips()
    {
        var tips = _databaseHelper.GetRandomTips(7);
        var stackLayout = new StackLayout { Padding = 10, VerticalOptions = LayoutOptions.Center };

        foreach (var tip in tips)
        {
            var border = new Border
            {
                Stroke = new SolidColorBrush(Color.FromArgb("#2B463C")),
                StrokeThickness = 1,
                StrokeShape = new RoundRectangle { CornerRadius = 5 },
                Background = new SolidColorBrush(Colors.White),
                Padding = 10,
                Margin = 5
            };

            var tipLabel = new Label
            {
                Text = tip,
                FontSize = 20,
                TextColor = Color.FromArgb("#2B463C")
            };
            
            // Add label to border
            border.Content = tipLabel;

            // Add border to layout
            stackLayout.Children.Add(border);
        }

    // Clear existing children and add new tips
    ((StackLayout)Content.FindByName("TipsStackLayout")).Children.Clear();
    ((StackLayout)Content.FindByName("TipsStackLayout")).Children.Add(stackLayout);
    }
    private async void OnHomeButtonClicked(object sender, EventArgs e)
    {
        // Optionally perform any asynchronous operations here
        await SomeAsyncOperation();

        // Pop all pages off the navigation stack until we reach the root page (MainPage)
        await Navigation.PopToRootAsync();
    }

    // Example of an asynchronous operation
    private async Task SomeAsyncOperation()
    {
        // Simulate an asynchronous operation (e.g., saving data, logging, etc.)
        await Task.Delay(500); // Simulate a delay
    }
}
