using System;
using System.Collections.Generic;
using System.Linq; // Make sure to include this for LINQ methods
using EcoTracker.Models;
using Microsoft.Maui.Controls;

namespace EcoTracker.Pages
{
    public partial class Goals : ContentPage
    {
        private GoalsDatabase goalsDatabase;

        public Goals()
        {
            InitializeComponent();
            goalsDatabase = new GoalsDatabase();
            LoadGoals();

            // Subscribe to messages for goal updates
            MessagingCenter.Subscribe<Goals, string>(this, "GoalUpdated", (sender, message) => LoadGoals());
            MessagingCenter.Subscribe<Goals, int>(this, "GoalDeleted", (sender, goalId) => LoadGoals());
        }

        private void LoadGoals()
        {
            var allGoals = goalsDatabase.GetGoals();

            // Separate active and completed goals
            var activeGoals = allGoals.Where(g => !g.IsCompleted).ToList();
            var completedGoals = allGoals.Where(g => g.IsCompleted).ToList();

            // Combine active and completed goals (completed goals at the bottom)
            var sortedGoals = activeGoals.Concat(completedGoals).ToList();

            GoalsListView.ItemsSource = sortedGoals; // Bind the ListView to the sorted goals list
        }

        private void OnAddGoalClicked(object sender, EventArgs e)
        {
            // Get the goal details from input fields
            string goalDescription = GoalDescriptionEntry.Text;
            DateTime targetDate = TargetDatePicker.Date;
            double? distance = string.IsNullOrWhiteSpace(DistanceEntry.Text) ? (double?)null : Convert.ToDouble(DistanceEntry.Text);
            double? energy = string.IsNullOrWhiteSpace(EnergyEntry.Text) ? (double?)null : Convert.ToDouble(EnergyEntry.Text);
            double? waste = string.IsNullOrWhiteSpace(WasteEntry.Text) ? (double?)null : Convert.ToDouble(WasteEntry.Text);

            // Validate input
            if (string.IsNullOrWhiteSpace(goalDescription))
            {
                DisplayAlert("Error", "Please enter a goal description.", "OK");
                return;
            }

            // Create a new goal object
            Goal newGoal = new Goal
            {
                Description = goalDescription,
                TargetDate = targetDate,
                Distance = distance,
                Energy = energy,
                Waste = waste,
                IsCompleted = false // Default to false when adding a new goal
            };

            // Add the goal to the database
            goalsDatabase.AddGoal(newGoal);

            // Refresh the ListView
            LoadGoals();

            // Optionally, display a success message
            DisplayAlert("Success", "Goal added successfully!", "OK");

            // Clear the input fields
            ClearInputFields();
        }

        private async void OnGoalSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null) return;

            var selectedGoal = (Goal)e.SelectedItem;

            // Check if the goal is completed
            if (selectedGoal.IsCompleted)
            {
                // Optionally, show a message indicating that the goal is completed
                await DisplayAlert("Goal Completed", "This goal has already been completed and cannot be edited.", "OK");
            }
            else
            {
                await Navigation.PushAsync(new EditGoals(selectedGoal));
            }

            // Clear selection
            GoalsListView.SelectedItem = null;
        }

        private void ClearInputFields()
        {
            // Clear all input fields after adding a goal
            GoalDescriptionEntry.Text = string.Empty;
            TargetDatePicker.Date = DateTime.Now;
            DistanceEntry.Text = string.Empty;
            EnergyEntry.Text = string.Empty;
            WasteEntry.Text = string.Empty;
        }

        private async void OnHomeButtonClicked(object sender, EventArgs e)
        {
            // Pop all pages off the navigation stack until we reach the root page (MainPage)
            await Navigation.PopToRootAsync();
        }

        // Unsubscribe from MessagingCenter when the page is destroyed
        protected override void OnDisappearing()
        {
            MessagingCenter.Unsubscribe<Goals, string>(this, "GoalUpdated");
            MessagingCenter.Unsubscribe<Goals, int>(this, "GoalDeleted");
            base.OnDisappearing();
        }
    }
}