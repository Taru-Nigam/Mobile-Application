using EcoTracker.Models;
using Microsoft.Maui.Controls;

namespace EcoTracker.Pages
{
    public partial class GoalCompletedPage : ContentPage
    {
        private Goal _completedGoal;

        public GoalCompletedPage(Goal completedGoal)
        {
            InitializeComponent(); // Ensure this is called first
            _completedGoal = completedGoal;
            LoadGoalData(); // Load metrics after initialization
        }

        private void LoadGoalData()
        {
            // Set the metrics text for the completed goal
            MetricsLabel.Text = $"Metrics:\nDistance Traveled: {_completedGoal.Distance} KMs\n" +
                                $"Energy Consumed: {_completedGoal.Energy} kWh\n" +
                                $"Waste Produced: {_completedGoal.Waste} Lbs";
            // Load the image if it exists
            if (!string.IsNullOrEmpty(_completedGoal.ImagePath))
            {
                GoalImage.Source = ImageSource.FromFile(_completedGoal.ImagePath);
            }
            else
            {
                GoalImage.Source = null; // Clear the image if no path is set
            }
        }

        private async void OnTakePictureClicked(object sender, EventArgs e)
        {
            // Check if permissions are granted
            var cameraStatus = await Permissions.CheckStatusAsync<Permissions.Camera>();
            var storageStatus = await Permissions.CheckStatusAsync<Permissions.StorageRead>();

            if (cameraStatus != PermissionStatus.Granted || storageStatus != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission Denied", "Camera and storage permissions are required to take a picture or select from the gallery.", "OK");
                return;
            }

            try
            {
                // Prompt the user to take a picture or select from the gallery
                var action = await DisplayActionSheet("Choose an option", "Cancel", null, "Take a Picture", "Select from Gallery");

                if (action == "Take a Picture")
                {
                    var photo = await MediaPicker.CapturePhotoAsync();
                    if (photo != null)
                    {
                        var stream = await photo.OpenReadAsync();
                        // Save the image path to the goal
                        _completedGoal.ImagePath = photo.FullPath; // Save the image path
                    }
                }
                else if (action == "Select from Gallery")
                {
                    var photo = await MediaPicker.PickPhotoAsync();
                    if (photo != null)
                    {
                        var stream = await photo.OpenReadAsync();
                        // Save the image path to the goal
                        _completedGoal.ImagePath = photo.FullPath; // Save the image path
                    }
                }

                // After setting the image path, update the goal in the database
                var database = new GoalsDatabase();
                database.UpdateGoalImagePath(_completedGoal.Id, _completedGoal.ImagePath); // Save the image path to the database

                // Update the displayed image
                GoalImage.Source = ImageSource.FromFile(_completedGoal.ImagePath);
            }
            catch (Exception ex)
            {
                // Log the exception for debugging
                System.Diagnostics.Debug.WriteLine($"Error: {ex.Message}");
                await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");

                // Check if we can navigate back
                if (Navigation.NavigationStack.Count > 1)
                {
                    await Navigation.PopAsync();
                }
            }
        }

        private async void OnGoalAchievedClicked(object sender, EventArgs e)
        {
            // Mark the goal as completed in the database
            _completedGoal.IsCompleted = true;
            var database = new GoalsDatabase();
            database.UpdateGoal(_completedGoal);

            MessagingCenter.Send(this, "GoalUpdated", "Goal has been achieved.");
            await Navigation.PopToRootAsync();
        }
    }
}