﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;

namespace EcoTracker
{
    class CalculatorEntries
    {
        private string dbPath;

        public CalculatorEntries()
        {
            dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "eco_tracker.db");
            CreateDatabase();
        }

        private void CreateDatabase()
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                CREATE TABLE IF NOT EXISTS CarbonFootprintEntries (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    DistanceTraveled REAL NOT NULL,
                    EnergyConsumed REAL NOT NULL,
                    WasteProduced REAL NOT NULL,
                    CarbonFootprint REAL NOT NULL
                )";
                command.ExecuteNonQuery();
            }
        }

        public void UpdateEntry(double distance, double energy, double waste, double footprint)
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                INSERT INTO CarbonFootprintEntries (DistanceTraveled, EnergyConsumed, WasteProduced, CarbonFootprint)
                VALUES ($distance, $energy, $waste, $footprint)";
                command.Parameters.AddWithValue("$distance", distance);
                command.Parameters.AddWithValue("$energy", energy);
                command.Parameters.AddWithValue("$waste", waste);
                command.Parameters.AddWithValue("$footprint", footprint);
                command.ExecuteNonQuery();
            }
        }

        public List<string> GetEntries()
        {
            var entries = new List<string>();
            double totalDistance = 0;
            double totalEnergy = 0;
            double totalWaste = 0;
            double totalFootprint = 0;

            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();

                // Aggregate all entries
                command.CommandText = "SELECT SUM(DistanceTraveled), SUM(EnergyConsumed), SUM(WasteProduced), SUM(CarbonFootprint) FROM CarbonFootprintEntries";
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        totalDistance = reader.IsDBNull(0) ? 0 : reader.GetDouble(0);
                        totalEnergy = reader.IsDBNull(1) ? 0 : reader.GetDouble(1);
                        totalWaste = reader.IsDBNull(2) ? 0 : reader.GetDouble(2);
                        totalFootprint = reader.IsDBNull(3) ? 0 : reader.GetDouble(3);
                    }
                }
            }

            // Add aggregated totals to the entries list
            entries.Add($" Distance: {totalDistance:F2} KM\n" +
                        $" Energy: {totalEnergy:F2} kWh\n" +
                        $" Waste: {totalWaste:F2} Lbs\n" +
                        $" Carbon Footprint: \n" +
                        $" {totalFootprint:F2} kg CO2");

            return entries;
        }   
    }
}