using System;
using System.Threading.Tasks; // Ensure this is included for Task
using Microsoft.Maui.Controls;
using EcoTracker.Models; // Ensure this namespace is included

namespace EcoTracker.Pages
{
    public partial class CompletedGoalsPage : ContentPage
    {
        private Goal goal; // Change from Goals to Goal

        public CompletedGoalsPage(Goal selectedGoal) // Change parameter type to Goal
        {
            InitializeComponent();
            goal = selectedGoal;

            // Display goal details
            DisplayGoalDetails();
        }

        private void DisplayGoalDetails()
        {
            // Display goal details
            DescriptionLabel.Text = goal.Description;
            TargetDateLabel.Text = goal.TargetDate?.ToString("MMMM dd, yyyy");
            DistanceLabel.Text = goal.Distance?.ToString() + " km";
            EnergyLabel.Text = goal.Energy?.ToString() + " kWh";
            WasteLabel.Text = goal.Waste?.ToString() + " kg";

            // Set labels to visible
            DescriptionLabel.IsVisible = true;
            TargetDateLabel.IsVisible = true;
            DistanceLabel.IsVisible = true;
            EnergyLabel.IsVisible = true;
            WasteLabel.IsVisible = true;

            // Load the image if it exists and the goal is completed
            if (goal.IsCompleted && !string.IsNullOrEmpty(goal.ImagePath))
            {
                GoalImage.Source = goal.ImagePath; // Assuming ImagePath is a valid URI or file path
                GoalImage.IsVisible = true; // Show the image
                RemoveImageButton.IsVisible = true; // Show the remove button if an image is attached
            }
            else
            {
                GoalImage.IsVisible = false; // Hide the image if no path is attached
                RemoveImageButton.IsVisible = false; // Hide the remove button if no image is attached
            }
        }

        private async void OnSelectImageClicked(object sender, EventArgs e)
        {
            // Display an action sheet to choose between taking a photo or picking from the gallery
            string action = await DisplayActionSheet("Select Image", "Cancel", null, "Take Photo", "Pick from Gallery");

            if (action == "Take Photo")
            {
                await TakePhotoAsync();
            }
            else if (action == "Pick from Gallery")
            {
                await PickPhotoAsync();
            }
        }

        private async Task TakePhotoAsync()
        {
            try
            {
                var photo = await MediaPicker.CapturePhotoAsync(new MediaPickerOptions
                {
                    Title = "Take a photo"
                });

                if (photo != null)
                {
                    var stream = await photo.OpenReadAsync();
                    GoalImage.Source = ImageSource.FromStream(() => stream);
                    goal.ImagePath = photo.FullPath; // Save the path to the goal
                    RemoveImageButton.IsVisible = true; // Show the remove button
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"Unable to take photo: {ex.Message}", "OK");
            }
        }

        private async Task PickPhotoAsync()
        {
            try
            {
                var result = await MediaPicker.PickPhotoAsync(new MediaPickerOptions
                {
                    Title = "Pick a photo"
                });

                if (result != null)
                {
                    var stream = await result.OpenReadAsync();
                    GoalImage.Source = ImageSource.FromStream(() => stream);
                    goal.ImagePath = result.FullPath; // Save the path to the goal
                    RemoveImageButton.IsVisible = true; // Show the remove button
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"Unable to pick photo: {ex.Message}", "OK");
            }
        }

        private async void OnSaveChangesClicked(object sender, EventArgs e)
        {
            // Update only the image path in the database
            var goalsDatabase = new GoalsDatabase();
            goalsDatabase.UpdateGoalImagePath(goal.Id, goal.ImagePath); // Update only the ImagePath

            await DisplayAlert("Success", "Changes saved successfully!", "OK");
            await Navigation.PopAsync();
        }

        private async void OnDeleteGoalClicked(object sender, EventArgs e)
        {
            bool confirm = await DisplayAlert("Delete Goal", "Are you sure you want to delete this goal?", "Yes", "No");
            if (confirm)
            {
                var goalsDatabase = new GoalsDatabase();
                goalsDatabase.DeleteGoal(goal.Id);
                await Navigation.PopAsync(); // Navigate back after deletion
            }
        }

        private void OnShareGoalClicked(object sender, EventArgs e)
        {
            string shareContent = $"I achieved my carbon footprint metrics:\n" +
                                  $"Description: {goal.Description}\n" +
                                  $"Target Date: {goal.TargetDate?.ToShortDateString() ?? "No target date"}\n" +
                                  $"Distance: {goal.Distance} km\n" +
                                  $"Energy: {goal.Energy} kWh\n" +
                                  $"Waste: {goal.Waste} kg\n" +
                                  $"You guys should use this app too!! Great app!!";

            Share.RequestAsync(new ShareTextRequest
            {
                Text = shareContent,
                Title = "Share Goal"
            });
        }

        private void OnRemoveImageClicked(object sender, EventArgs e)
        {
            GoalImage.Source = null; // Clear the image
            goal.ImagePath = null; // Remove the image path from the goal
            RemoveImageButton.IsVisible = false; // Hide the remove button
        }
    }
}