﻿using System;
using System.Collections.Generic;
using System.IO; // Added for Path
using Microsoft.Data.Sqlite;

namespace EcoTracker
{
    // Class for managing carbon footprint entries in the EcoTracker application
    class CalculatorEntries
    {
        // Path to the SQLite database file
        private string dbPath;

        // Constructor for CalculatorEntries
        public CalculatorEntries()
        {
            // Set the database path to the local application data folder
            dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "eco_tracker.db");
            // Create the database and its tables if they do not exist
            CreateDatabase();
        }

        // Method to create the database and the necessary tables
        private void CreateDatabase()
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open(); // Open the database connection
                var command = connection.CreateCommand();
                // SQL command to create the CarbonFootprintEntries table if it doesn't exist
                command.CommandText = @"
                CREATE TABLE IF NOT EXISTS CarbonFootprintEntries (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    DistanceTraveled REAL NOT NULL,
                    EnergyConsumed REAL NOT NULL,
                    WasteProduced REAL NOT NULL,
                    CarbonFootprint REAL NOT NULL
                )";
                command.ExecuteNonQuery(); // Execute the command to create the table
            }
        }

        // Method to update the database with a new carbon footprint entry
        public void UpdateEntry(double distance, double energy, double waste, double footprint)
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open(); // Open the database connection
                var command = connection.CreateCommand();
                // SQL command to insert a new entry into the CarbonFootprintEntries table
                command.CommandText = @"
                INSERT INTO CarbonFootprintEntries (DistanceTraveled, EnergyConsumed, WasteProduced, CarbonFootprint)
                VALUES ($distance, $energy, $waste, $footprint)";
                // Add parameters to prevent SQL injection
                command.Parameters.AddWithValue("$distance", distance);
                command.Parameters.AddWithValue("$energy", energy);
                command.Parameters.AddWithValue("$waste", waste);
                command.Parameters.AddWithValue("$footprint", footprint);
                command.ExecuteNonQuery(); // Execute the insert command
            }
        }

        // Method to retrieve and aggregate all carbon footprint entries from the database
        public List<string> GetEntries()
        {
            var entries = new List<string>();
            double totalDistance = 0;
            double totalEnergy = 0;
            double totalWaste = 0;
            double totalFootprint = 0;

            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open(); // Open the database connection
                var command = connection.CreateCommand();

                // SQL command to aggregate all entries and calculate totals
                command.CommandText = "SELECT SUM(DistanceTraveled), SUM(EnergyConsumed), SUM(WasteProduced), SUM(CarbonFootprint) FROM CarbonFootprintEntries";
                using (var reader = command.ExecuteReader())
                {
                    // Read the aggregated results
                    if (reader.Read())
                    {
                        totalDistance = reader.IsDBNull(0) ? 0 : reader.GetDouble(0);
                        totalEnergy = reader.IsDBNull(1) ? 0 : reader.GetDouble(1);
                        totalWaste = reader.IsDBNull(2) ? 0 : reader.GetDouble(2);
                        totalFootprint = reader.IsDBNull(3) ? 0 : reader.GetDouble(3);
                    }
                }
            }

            // Add aggregated totals to the entries list in a formatted string
            entries.Add($" Distance: {totalDistance:F2} KM\n" +
                        $" Energy: {totalEnergy:F2} kWh\n" +
                        $" Waste: {totalWaste:F2} Lbs\n" +
                        $" Carbon Footprint: \n" +
                        $" {totalFootprint:F2} kg CO2");

            return entries; // Return the list of aggregated entries
        }
    }
}