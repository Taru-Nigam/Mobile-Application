﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite; // Use Microsoft.Data.Sqlite for .NET MAUI

namespace EcoTracker
{
    // Helper class for managing the SQLite database for sustainability tips
    public class DatabaseHelper
    {
        // Path to the SQLite database file
        private string dbPath;

        // Constructor for DatabaseHelper
        public DatabaseHelper()
        {
            // Set the database path to the local application data folder
            dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "sustainability_tips.db");
            // Create the database and its tables if they do not exist
            CreateDatabase();
        }

        // Method to create the database and the necessary tables
        private void CreateDatabase()
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open(); // Open the database connection
                var command = connection.CreateCommand();
                // SQL command to create the SustainabilityTips table if it doesn't exist
                command.CommandText = @"
                CREATE TABLE IF NOT EXISTS SustainabilityTips (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Tip TEXT NOT NULL
                )";
                command.ExecuteNonQuery(); // Execute the command
            }
        }

        // Flag to check if the database has been seeded with initial data
        private static bool _isSeeded = false;

        // Method to seed the database with initial sustainability tips
        public void SeedDatabase()
        {
            // Return if the database has already been seeded
            if (_isSeeded) return;

            // List of sustainability tips to be added to the database
            var tips = new List<string>
            {
                "Reduce, Reuse, Recycle",
                "Use energy-efficient appliances",
                "Opt for public transport or carpool",
                "Support local and sustainable products",
                "Plant trees and maintain green spaces",
                "Switch off lights and unplug electronics when not in use.",
                "Use energy-efficient appliances and LED bulbs.",
                "Set thermostats to save energy in winter and summer.",
                "Incorporate more plant-based meals into your diet.",
                "Reduce meat and dairy consumption on certain days.",
                "Support local and organic farms for produce.",
            };

            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open(); // Open the database connection
                // Check if the SustainabilityTips table is empty
                var checkCommand = connection.CreateCommand();
                checkCommand.CommandText = "SELECT COUNT(*) FROM SustainabilityTips";
                var count = Convert.ToInt64(checkCommand.ExecuteScalar()); // Get the count of existing tips

                // If the table is empty, insert the initial tips
                if (count == 0)
                {
                    foreach (var tip in tips)
                    {
                        var insertCommand = connection.CreateCommand();
                        // SQL command to insert a new tip into the table
                        insertCommand.CommandText = "INSERT INTO SustainabilityTips (Tip) VALUES ($tip)";
                        insertCommand.Parameters.AddWithValue("$tip", tip); // Add the tip as a parameter
                        insertCommand.ExecuteNonQuery(); // Execute the insert command
                    }
                }
            }

            // Mark the database as seeded
            _isSeeded = true;
        }

        // Method to retrieve a specified number of random sustainability tips from the database
        public List<string> GetRandomTips(int count)
        {
            var tips = new List<string>();
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open(); // Open the database connection
                var command = connection.CreateCommand();
                // SQL command to select a random set of tips from the table
                command.CommandText = $"SELECT Tip FROM SustainabilityTips ORDER BY RANDOM() LIMIT {count}";
                using (var reader = command.ExecuteReader())
                {
                    // Read the tips from the database and add them to the list
                    while (reader.Read())
                    {
                        tips.Add(reader.GetString(0));
                    }
                }
            }
            return tips; // Return the list of random tips
        }
    }
}