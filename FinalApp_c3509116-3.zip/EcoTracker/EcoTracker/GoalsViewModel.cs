using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EcoTracker.Models;
using System.Collections.ObjectModel;

namespace EcoTracker.ViewModels
{
    public partial class GoalsViewModel : ObservableObject
    {
        // Instance of the database to interact with goal data
        private readonly GoalsDatabase _goalsDatabase;
        // Constructor for GoalsViewModel
        public GoalsViewModel()
        {
            _goalsDatabase = new GoalsDatabase();
            LoadGoals();
        }
        // Observable property to hold the collection of goals
        [ObservableProperty]
        private ObservableCollection<Goal> _goals;

        // Method to load goals from the database into the ObservableCollection
        public void LoadGoals()
        {            
            // Retrieve the list of goals from the database
            var goalsList = _goalsDatabase.GetGoals();
            Goals = new ObservableCollection<Goal>(goalsList);
        }
        // Command to add a new goal to the database and refresh the goals list
        [RelayCommand]
        public void AddGoal(Goal newGoal)
        {
            // Add the new goal to the database
            _goalsDatabase.AddGoal(newGoal);
            // Reload the goals to reflect the changes
            LoadGoals();
        }
        // Command to update an existing goal in the database and refresh the goals list
        [RelayCommand]
        public void UpdateGoal(Goal updatedGoal)
        {
            // Update the goal in the database
            _goalsDatabase.UpdateGoal(updatedGoal);
            LoadGoals();
        }
    }
}