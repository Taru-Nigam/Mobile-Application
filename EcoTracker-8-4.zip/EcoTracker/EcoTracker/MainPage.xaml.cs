﻿using System;
using Microsoft.Maui.Controls;
using System.Collections.Generic;

using EcoTracker.Pages;

namespace EcoTracker
{
    public partial class MainPage : ContentPage
    {
        private DatabaseHelper _databaseHelper;
        private CalculatorEntries _calculatorEntries;

        public MainPage()
        {
            InitializeComponent();
            _databaseHelper = new DatabaseHelper();
            _calculatorEntries = new CalculatorEntries();
            LoadEntries();
            LoadDailyTip();
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await RequestPermissionsAsync(); // Request permissions when the page appears
            LoadEntries(); // Load entries every time the page appears
        }

        private void LoadEntries()
        {
            List<string> entries = _calculatorEntries.GetEntries();
            EntriesStack.Children.Clear(); // Clear previous entries before loading new ones
            foreach (var entry in entries)
            {
                var label = new Label
                {
                    Text = entry,
                    FontSize = 16
                };
                EntriesStack.Children.Add(label);
            }
        }

        private async Task RequestPermissionsAsync()
        {
            // Request camera permission
            var cameraStatus = await Permissions.RequestAsync<Permissions.Camera>();
            if (cameraStatus != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission Denied", "Camera permission is required to take a picture.", "OK");
                return;
            }

            // Request storage permission
            var storageStatus = await Permissions.RequestAsync<Permissions.StorageRead>();
            if (storageStatus != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission Denied", "Storage permission is required to access the gallery.", "OK");
                return;
            }

            // Optionally, you can also request write storage permission if you plan to save images
            var storageWriteStatus = await Permissions.RequestAsync<Permissions.StorageWrite>();
            if (storageWriteStatus != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission Denied", "Storage write permission is required to save images.", "OK");
                return;
            }
        }

        private void LoadDailyTip()
        {
            var dailyTips = _databaseHelper.GetRandomTips(1);
            DailyTipLabel.Text = dailyTips.Count > 0 ? dailyTips[0] : "No tip available";
        }

        private async void OnCalculatorClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Calculator());
        }

        private async void OnSustainabilityTipsClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Tips());
        }

        private async void OnGoalsClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Goals());
        }

    }
}
