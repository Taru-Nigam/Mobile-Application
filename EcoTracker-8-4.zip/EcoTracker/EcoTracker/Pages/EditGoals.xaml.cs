using EcoTracker.Models;
using Microsoft.Maui.Controls;

namespace EcoTracker.Pages
{
    public partial class EditGoals : ContentPage
    {
        private Goal _currentGoal;
        private GoalsDatabase _database = new GoalsDatabase();

        public EditGoals(Goal goal)
        {
            InitializeComponent();
            _currentGoal = goal;
            LoadGoalData();
        }

        private void LoadGoalData()
        {
            DescriptionEditor.Text = _currentGoal.Description ?? string.Empty; // Set to empty if null
            AdditionalDetailsEditor.Text = _currentGoal.AdditionalDetails ?? string.Empty; // Set to empty if null
            TargetDatePicker.Date = _currentGoal.TargetDate ?? DateTime.Now; // Default to now if null
            DistanceEntry.Text = _currentGoal.Distance?.ToString() ?? string.Empty; // Set to empty if null
            EnergyEntry.Text = _currentGoal.Energy?.ToString() ?? string.Empty; // Set to empty if null
            WasteEntry.Text = _currentGoal.Waste?.ToString() ?? string.Empty; // Set to empty if null
        }

        private async void OnGoalAchievedClicked(object sender, EventArgs e)
        {
            // Mark the goal as completed in the database
            _currentGoal.IsCompleted = true; // Ensure this property exists in your Goal model
            _database.UpdateGoal(_currentGoal);

            // Navigate to the GoalCompletedPage with the completed goal
            await Navigation.PushAsync(new GoalCompletedPage(_currentGoal));
        }

        private async void OnSaveClicked(object sender, EventArgs e)
        {
            // Check if the selected date is in the past
            if (TargetDatePicker.Date < DateTime.Now)
            {
                await DisplayAlert("Invalid Date", "The selected date has already passed. Please choose a future date.", "OK");
                return; // Exit the method if the date is invalid
            }

            // Proceed with saving the goal if the date is valid
            _currentGoal.Description = DescriptionEditor.Text;
            _currentGoal.AdditionalDetails = AdditionalDetailsEditor.Text;
            _currentGoal.TargetDate = TargetDatePicker.Date;

            if (double.TryParse(DistanceEntry.Text, out double distance))
            {
                _currentGoal.Distance = distance;
            }
            else
            {
                _currentGoal.Distance = null; // or handle invalid input as needed
            }

            if (double.TryParse(EnergyEntry.Text, out double energy))
            {
                _currentGoal.Energy = energy;
            }
            else
            {
                _currentGoal.Energy = null; // or handle invalid input as needed
            }

            if (double.TryParse(WasteEntry.Text, out double waste))
            {
                _currentGoal.Waste = waste;
            }
            else
            {
                _currentGoal.Waste = null; // or handle invalid input as needed
            }

            _database.UpdateGoal(_currentGoal);

            // Notify the Goals page to refresh
            MessagingCenter.Send(this, "GoalUpdated", _currentGoal);

            await DisplayAlert("Success", "Goal updated successfully!", "OK");
            await Navigation.PopAsync();
        }

        private async void OnDeleteClicked(object sender, EventArgs e)
        {
            bool confirm = await DisplayAlert("Confirm Delete", "Are you sure you want to delete this goal?", "Yes", "No");
            if (confirm)
            {
                // Delete the goal from the database
                _database.DeleteGoal(_currentGoal.Id); // Assuming you have a DeleteGoal method in GoalsDatabase

                // Notify the Goals page to refresh
                MessagingCenter.Send(this, "GoalDeleted", _currentGoal.Id);

                await Navigation.PopAsync(); // Navigate back to the previous page
            }
        }
    }
}