using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using EcoTracker.Models;
using Microsoft.Maui.Controls;

namespace EcoTracker.Pages
{
    public partial class Goals : ContentPage
    {
        private GoalsDatabase goalsDatabase;
        private ObservableCollection<Goal> activeGoals;
        private ObservableCollection<Goal> completedGoals;

        public Goals()
        {
            InitializeComponent();
            goalsDatabase = new GoalsDatabase();
            activeGoals = new ObservableCollection<Goal>();
            completedGoals = new ObservableCollection<Goal>();
            ActiveGoalsListView.ItemsSource = activeGoals;
            CompletedGoalsListView.ItemsSource = completedGoals;

            // Subscribe to MessagingCenter for goal updates and deletions
            MessagingCenter.Subscribe<EditGoals, Goal>(this, "GoalUpdated", async (sender, updatedGoal) => await LoadGoalsAsync());
            MessagingCenter.Subscribe<EditGoals, int>(this, "GoalDeleted", async (sender, goalId) => await LoadGoalsAsync());
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await RequestPermissionsAsync(); // Request necessary permissions
            await LoadGoalsAsync(); // Load goals every time the page appears
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            // Unsubscribe from MessagingCenter
            MessagingCenter.Unsubscribe<EditGoals, Goal>(this, "GoalUpdated");
            MessagingCenter.Unsubscribe<EditGoals, int>(this, "GoalDeleted");
        }

        private async Task LoadGoalsAsync()
        {
            try
            {
                // Retrieve all goals from the database
                var allGoals = await Task.Run(() => goalsDatabase.GetGoals());
                Console.WriteLine($"Total goals retrieved: {allGoals.Count}");

                activeGoals.Clear();
                completedGoals.Clear();

                // Separate active and completed goals
                foreach (var goal in allGoals)
                {
                    if (goal.IsCompleted)
                    {
                        completedGoals.Add(goal);
                    }
                    else
                    {
                        activeGoals.Add(goal);
                    }
                }

                Console.WriteLine($"Active goals: {activeGoals.Count}, Completed goals: {completedGoals.Count}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading goals: {ex.Message}");
                await DisplayAlert("Error", "Failed to load goals.", "OK");
            }
        }

        private async void OnAddGoalClicked(object sender, EventArgs e)
        {
            // Get the goal details from input fields
            string goalDescription = GoalDescriptionEntry.Text;
            DateTime targetDate = TargetDatePicker.Date;
            double? distance = string.IsNullOrWhiteSpace(DistanceEntry.Text) ? (double?)null : Convert.ToDouble(DistanceEntry.Text);
            double? energy = string.IsNullOrWhiteSpace(EnergyEntry.Text) ? (double?)null : Convert.ToDouble(EnergyEntry.Text);
            double? waste = string.IsNullOrWhiteSpace(WasteEntry.Text) ? (double?)null : Convert.ToDouble(WasteEntry.Text);

            // Validate input
            if (string.IsNullOrWhiteSpace(goalDescription))
            {
                await DisplayAlert("Error", "Please enter a goal description.", "OK");
                return;
            }

            // Create a new goal object
            Goal newGoal = new Goal
            {
                Description = goalDescription,
                TargetDate = targetDate,
                Distance = distance,
                Energy = energy,
                Waste = waste
            };

            try
            {
                // Add the goal to the database and refresh the ListViews
                await Task.Run(() => goalsDatabase.AddGoal(newGoal));
                await LoadGoalsAsync();
                await DisplayAlert("Success", "Goal added successfully!", "OK");

                // Clear the input fields
                ClearInputFields();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error adding goal: {ex.Message}");
                await DisplayAlert("Error", "Failed to add goal.", "OK");
            }
        }

        private async void OnGoalSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null) return;

            var selectedGoal = (Goal)e.SelectedItem;
            await Navigation.PushAsync(new EditGoals(selectedGoal));

            // Clear selection
            if (sender is ListView listView)
            {
                listView.SelectedItem = null;
            }
        }

        private async Task RequestPermissionsAsync()
        {
            // Implement your permission request logic here
        }

        private async void OnHomeButtonClicked(object sender, EventArgs e)
        {
            await Navigation.PopToRootAsync(); // Navigate back to the root page
        }

        private void ClearInputFields()
        {
            // Clear all input fields after adding a goal
            GoalDescriptionEntry.Text = string.Empty;
            TargetDatePicker.Date = DateTime.Now;
            DistanceEntry.Text = string.Empty;
            EnergyEntry.Text = string.Empty;
            WasteEntry.Text = string.Empty;
        }
    }
}