﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Data.Sqlite;
using EcoTracker.Models;

namespace EcoTracker
{
    public class GoalsDatabase
    {
        private readonly string dbPath;

        public GoalsDatabase()
        {
            dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "goals.db");
            CreateDatabase();
        }

        private void CreateDatabase()
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();

                // Create the Goals table if it doesn't exist
                command.CommandText = @"
                CREATE TABLE IF NOT EXISTS Goals (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Description TEXT NOT NULL,
                    AdditionalDetails TEXT,
                    TargetDate TEXT NOT NULL,
                    IsCompleted INTEGER NOT NULL DEFAULT 0,
                    Distance REAL,
                    Energy REAL,
                    Waste REAL,
                    ImagePath TEXT
                )";
                command.ExecuteNonQuery();

                // Check if the IsCompleted column exists and add it if not
                command.CommandText = "PRAGMA table_info(Goals)";
                using (var reader = command.ExecuteReader())
                {
                    bool hasIsCompleted = false;
                    while (reader.Read())
                    {
                        if (reader.GetString(1) == "IsCompleted")
                        {
                            hasIsCompleted = true;
                            break;
                        }
                    }

                    if (!hasIsCompleted)
                    {
                        command.CommandText = "ALTER TABLE Goals ADD COLUMN IsCompleted INTEGER NOT NULL DEFAULT 0";
                        command.ExecuteNonQuery();
                    }
                }
            }
        }

        public void AddGoal(Goal goal)
        {
            // Check if the goal already exists
            if (GetGoals().Any(g => g.Description == goal.Description && g.TargetDate == goal.TargetDate))
            {
                Console.WriteLine("Goal already exists.");
                return; // Exit if the goal already exists
            }

            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                INSERT INTO Goals (Description, AdditionalDetails, TargetDate, IsCompleted, Distance, Energy, Waste, ImagePath)
                VALUES ($description, $additionalDetails, $targetDate, $isCompleted, $distance, $energy, $waste, $imagePath)";
                command.Parameters.AddWithValue("$description", goal.Description);
                command.Parameters.AddWithValue("$additionalDetails", (object)goal.AdditionalDetails ?? DBNull.Value);
                command.Parameters.AddWithValue("$targetDate", goal.TargetDate.HasValue ? goal.TargetDate.Value.ToString("o") : (object)DBNull.Value);
                command.Parameters.AddWithValue("$isCompleted", goal.IsCompleted ? 1 : 0);
                command.Parameters.AddWithValue("$distance", goal.Distance);
                command.Parameters.AddWithValue("$energy", goal.Energy);
                command.Parameters.AddWithValue("$waste", goal.Waste);
                command.Parameters.AddWithValue("$imagePath", (object)goal.ImagePath ?? DBNull.Value);

                try
                {
                    command.ExecuteNonQuery();
                    Console.WriteLine("Goal added successfully.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error adding goal: {ex.Message}");
                }
            }
        }

        public List<Goal> GetGoals()
        {
            var goals = new List<Goal>();
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT Id, Description, AdditionalDetails, TargetDate, IsCompleted, Distance, Energy, Waste, ImagePath FROM Goals";
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        goals.Add(new Goal
                        {
                            Id = reader.GetInt32(0),
                            Description = reader.GetString(1),
                            AdditionalDetails = reader.IsDBNull(2) ? null : reader.GetString(2),
                            TargetDate = DateTime.Parse(reader.GetString(3)),
                            IsCompleted = reader.GetInt32(4) == 1,
                            Distance = reader.IsDBNull(5) ? (double?)null : reader.GetDouble(5),
                            Energy = reader.IsDBNull(6) ? (double?)null : reader.GetDouble(6),
                            Waste = reader.IsDBNull(7) ? (double?)null : reader.GetDouble(7),
                            ImagePath = reader.IsDBNull(8) ? null : reader.GetString(8)
                        });
                    }
                }
            }
            return goals;
        }

        public void UpdateGoal(Goal goal)
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                UPDATE Goals 
                SET Description = $description,
                    AdditionalDetails = $additionalDetails,
                    TargetDate = $targetDate,
                    IsCompleted = $isCompleted,
                    Distance = $distance,
                    Energy = $energy,
                    Waste = $waste,
                    ImagePath = $imagePath
                WHERE Id = $id";
                command.Parameters.AddWithValue("$id", goal.Id);
                command.Parameters.AddWithValue("$description", goal.Description);
                command.Parameters.AddWithValue("$additionalDetails", (object)goal.AdditionalDetails ?? DBNull.Value);
                command.Parameters.AddWithValue("$targetDate", goal.TargetDate.HasValue ? goal.TargetDate.Value.ToString("o") : (object)DBNull.Value);
                command.Parameters.AddWithValue("$isCompleted", goal.IsCompleted ? 1 : 0);
                command.Parameters.AddWithValue("$distance", goal.Distance);
                command.Parameters.AddWithValue("$energy", goal.Energy);
                command.Parameters.AddWithValue("$waste", goal.Waste);
                command.Parameters.AddWithValue("$imagePath", (object)goal.ImagePath ?? DBNull.Value);
                command.ExecuteNonQuery();
            }
        }

        public void CompleteGoal(int goalId)
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "UPDATE Goals SET IsCompleted = 1 WHERE Id = $id";
                command.Parameters.AddWithValue("$id", goalId);
                command.ExecuteNonQuery();
            }
        }

        public void DeleteGoal(int goalId)
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "DELETE FROM Goals WHERE Id = $id";
                command.Parameters.AddWithValue("$id", goalId);
                command.ExecuteNonQuery();
            }
        }

        public Goal GetGoalById(int id)
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
            SELECT Id, Description, AdditionalDetails, TargetDate, IsCompleted, Distance, Energy, Waste, ImagePath
            FROM Goals
            WHERE Id = $id";
                command.Parameters.AddWithValue("$id", id);

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Goal
                        {
                            Id = reader.GetInt32(0),
                            Description = reader.GetString(1),
                            AdditionalDetails = reader.IsDBNull(2) ? null : reader.GetString(2),
                            TargetDate = DateTime.Parse(reader.GetString(3)),
                            IsCompleted = reader.GetInt32(4) == 1,
                            Distance = reader.IsDBNull(5) ? (double?)null : reader.GetDouble(5),
                            Energy = reader.IsDBNull(6) ? (double?)null : reader.GetDouble(6),
                            Waste = reader.IsDBNull(7) ? (double?)null : reader.GetDouble(7),
                            ImagePath = reader.IsDBNull(8) ? null : reader.GetString(8)
                        };
                    }
                }
            }
            return null; // Return null if the goal is not found
        }
    }
}