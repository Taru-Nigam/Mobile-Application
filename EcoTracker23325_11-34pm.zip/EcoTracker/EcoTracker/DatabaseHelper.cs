﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite; // Use Microsoft.Data.Sqlite for .NET MAUI


namespace EcoTracker
{
    public class DatabaseHelper
    {
        private string dbPath;

        public DatabaseHelper()
        {
            dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "sustainability_tips.db");
            CreateDatabase();
        }

        private void CreateDatabase()
        {
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                CREATE TABLE IF NOT EXISTS SustainabilityTips (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Tip TEXT NOT NULL
                )";
                command.ExecuteNonQuery();
            }
        }

        private static bool _isSeeded = false;

        public void SeedDatabase()
        {
            if (_isSeeded) return;
            var tips = new List<string>
        {
            "Reduce, Reuse, Recycle",
            "Use energy-efficient appliances",
            "Opt for public transport or carpool",
            "Support local and sustainable products",
            "Plant trees and maintain green spaces",
            "Switch off lights and unplug electronics when not in use.", 
            "Use energy-efficient appliances and LED bulbs.",
            "Set thermostats to save energy in winter and summer.",
            "Incorporate more plant-based meals into your diet.",
            "Reduce meat and dairy consumption on certain days.",
            "Support local and organic farms for produce.",

        };

            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                // Check if table is empty
                var checkCommand = connection.CreateCommand();
                checkCommand.CommandText = "SELECT COUNT(*) FROM SustainabilityTips";
                var count = Convert.ToInt64(checkCommand.ExecuteScalar());

                if (count == 0)
                {
                    // Insert only if table is empty
                    foreach (var tip in tips)
                    {
                        var insertCommand = connection.CreateCommand();
                        insertCommand.CommandText = "INSERT INTO SustainabilityTips (Tip) VALUES ($tip)";
                        insertCommand.Parameters.AddWithValue("$tip", tip);
                        insertCommand.ExecuteNonQuery();
                    }
                }
            }

            _isSeeded = true;
        }
        public List<string> GetRandomTips(int count)
        {
            var tips = new List<string>();
            using (var connection = new SqliteConnection($"Data Source={dbPath}"))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = $"SELECT Tip FROM SustainabilityTips ORDER BY RANDOM() LIMIT {count}";
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        tips.Add(reader.GetString(0));
                    }
                }
            }
            return tips;
        }
    }
}