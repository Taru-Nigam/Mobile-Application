using System;
using Microsoft.Maui.Controls;

namespace EcoTracker.Pages;

public partial class Calculator : ContentPage
{
    private CalculatorEntries _calculatorEntries;
    public Calculator()
	{
		InitializeComponent();
        _calculatorEntries = new CalculatorEntries();

    }
    private void OnCalculateClicked(object sender, EventArgs e)
    {
        // Get user inputs
        double distanceTraveled = double.TryParse(DistanceEntry.Text, out var distance) ? distance : 0;
        double energyConsumed = double.TryParse(EnergyEntry.Text, out var energy) ? energy : 0;
        double wasteProduced = double.TryParse(WasteEntry.Text, out var waste) ? waste : 0;

        // Calculate carbon footprint
        double carbonFootprint = CalculateCarbonFootprint(distanceTraveled, energyConsumed, wasteProduced);

        // Save entry to database
        _calculatorEntries.UpdateEntry(distanceTraveled, energyConsumed, wasteProduced, carbonFootprint);

        // Display the result
        DisplayAlert("Carbon Footprint", $"Your estimated carbon footprint is {carbonFootprint:F2} kg CO2.", "OK");
    }


    private double CalculateCarbonFootprint(double distance, double energy, double waste)
    {
        // Define emission factors
        const double distanceFactor = 0.2; // kg CO2 per KM
        const double energyFactor = 0.5; // kg CO2 per kWh
        const double wasteFactor = 0.1; // kg CO2 per lb

        // Calculate total carbon footprint
        double footprintFromDistance = distance * distanceFactor;
        double footprintFromEnergy = energy * energyFactor;
        double footprintFromWaste = waste * wasteFactor;

        return footprintFromDistance + footprintFromEnergy + footprintFromWaste;
    }
}