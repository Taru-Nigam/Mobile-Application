namespace EcoTracker.Pages;
using EcoTracker.Models;
using Microsoft.Maui.Controls;

public partial class GoalCompletedPage : ContentPage
{
    private Goal _completedGoal;

    public GoalCompletedPage(Goal completedGoal)
    {
        InitializeComponent(); // Ensure this is called first
        _completedGoal = completedGoal;
        LoadGoalMetrics(); // Load metrics after initialization
    }

    private void LoadGoalMetrics()
    {
        // Ensure MetricsLabel is initialized before setting its text
        if (MetricsLabel != null)
        {
            MetricsLabel.Text = $"Metrics:\nDistance Traveled: {_completedGoal.Distance} KMs\n" +
                                $"Energy Consumed: {_completedGoal.Energy} kWh\n" +
                                $"Waste Produced: {_completedGoal.Waste} Lbs";
        }
        else
        {
            // Handle the case where MetricsLabel is not initialized
            throw new InvalidOperationException("MetricsLabel is not initialized.");
        }
    }

    private async void OnTakePictureClicked(object sender, EventArgs e)
    {
        try
        {
            // Request permissions for camera and storage
            var cameraStatus = await Permissions.RequestAsync<Permissions.Camera>();
            if (cameraStatus != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission Denied", "Camera permission is required to take a picture.", "OK");
                return;
            }

            var storageStatus = await Permissions.RequestAsync<Permissions.StorageRead>();
            if (storageStatus != PermissionStatus.Granted)
            {
                await DisplayAlert("Permission Denied", "Storage permission is required to access the gallery.", "OK");
                return;
            }

            // Prompt the user to take a picture or select from the gallery
            var action = await DisplayActionSheet("Choose an option", "Cancel", null, "Take a Picture", "Select from Gallery");

            if (action == "Take a Picture")
            {
                var photo = await MediaPicker.CapturePhotoAsync();
                if (photo != null)
                {
                    var stream = await photo.OpenReadAsync();
                    // Save the photo stream to your app's history or database
                    // You can use a method similar to SavePhoto(stream);
                }
            }
            else if (action == "Select from Gallery")
            {
                var photo = await MediaPicker.PickPhotoAsync();
                if (photo != null)
                {
                    var stream = await photo.OpenReadAsync();
                    // Save the photo stream to your app's history or database
                    // You can use a method similar to SavePhoto(stream);
                }
            }
        }
        catch (Exception ex)
        {
            // Log the exception for debugging
            System.Diagnostics.Debug.WriteLine($"Error: {ex.Message}");
            await DisplayAlert("Error", $"An error occurred: {ex.Message}", "OK");

            // Check if we can navigate back
            if (Navigation.NavigationStack.Count > 1)
            {
                await Navigation.PopAsync();
            }
        }
    }
}