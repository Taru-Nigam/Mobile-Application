using System;
using System.Collections.Generic;
using EcoTracker.Models;
using Microsoft.Maui.Controls;

namespace EcoTracker.Pages
{
    public partial class Goals : ContentPage
    {
        private GoalsDatabase goalsDatabase;

        public Goals()
        {
            InitializeComponent();
            goalsDatabase = new GoalsDatabase();
            LoadGoals();

            // Subscribe to the MessagingCenter to listen for goal updates
            MessagingCenter.Subscribe<EditGoals, Goal>(this, "GoalUpdated", (sender, updatedGoal) =>
            {
                // Refresh the goals list when a goal is updated
                LoadGoals();
            });

            // Subscribe to the MessagingCenter to listen for goal deletions
            MessagingCenter.Subscribe<EditGoals, int>(this, "GoalDeleted", (sender, goalId) =>
            {
                // Refresh the goals list when a goal is deleted
                LoadGoals();
            });
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await RequestPermissionsAsync(); // Request permissions when the page appears
            LoadGoals(); // Load goals every time the page appears
        }

        private void LoadGoals()
        {
            // Retrieve all goals from the database
            var allGoals = goalsDatabase.GetGoals();
            Console.WriteLine($"Total goals retrieved: {allGoals.Count}");

            var activeGoals = new List<Goal>();
            var completedGoals = new List<Goal>();

            // Separate active and completed goals
            foreach (var goal in allGoals)
            {
                Console.WriteLine($"Goal: {goal.Description}, Completed: {goal.IsCompleted}");
                if (goal.IsCompleted)
                {
                    completedGoals.Add(goal);
                }
                else
                {
                    activeGoals.Add(goal);
                }
            }

            // Set the ItemsSource for both ListViews
            ActiveGoalsListView.ItemsSource = activeGoals;
            CompletedGoalsListView.ItemsSource = completedGoals;

            Console.WriteLine($"Active goals: {activeGoals.Count}, Completed goals: {completedGoals.Count}");
        }

        private void OnAddGoalClicked(object sender, EventArgs e)
        {
            // Get the goal description and target date
            string goalDescription = GoalDescriptionEntry.Text;
            DateTime targetDate = TargetDatePicker.Date;
            double? distance = string.IsNullOrWhiteSpace(DistanceEntry.Text) ? (double?)null : Convert.ToDouble(DistanceEntry.Text);
            double? energy = string.IsNullOrWhiteSpace(EnergyEntry.Text) ? (double?)null : Convert.ToDouble(EnergyEntry.Text);
            double? waste = string.IsNullOrWhiteSpace(WasteEntry.Text) ? (double?)null : Convert.ToDouble(WasteEntry.Text);

            // Validate input
            if (string.IsNullOrWhiteSpace(goalDescription))
            {
                DisplayAlert("Error", "Please enter a goal description.", "OK");
                return;
            }

            // Create a new goal object
            Goal newGoal = new Goal
            {
                Description = goalDescription,
                TargetDate = targetDate,
                Distance = distance,
                Energy = energy,
                Waste = waste
            };

            // Add the goal to the database
            goalsDatabase.AddGoal(newGoal);

            // Refresh the ListViews
            LoadGoals();

            // Optionally, display a success message
            DisplayAlert("Success", "Goal added successfully!", "OK");

            // Clear the input fields
            GoalDescriptionEntry.Text = string.Empty;
            TargetDatePicker.Date = DateTime.Now;
            DistanceEntry.Text = string.Empty;
            EnergyEntry.Text = string.Empty;
            WasteEntry.Text = string.Empty;
        }

        private async void OnGoalSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null) return;

            var selectedGoal = (Goal)e.SelectedItem;
            await Navigation.PushAsync(new EditGoals(selectedGoal));

            // Clear selection
            if (sender is ListView listView)
            {
                listView.SelectedItem = null;
            }
        }

        private async Task RequestPermissionsAsync()
        {
            // Implement your permission request logic here
            // For example, if you need to request storage permissions, you can do it here
        }

        private async void OnHomeButtonClicked(object sender, EventArgs e)
        {
            // Optionally perform any asynchronous operations here
            await SomeAsyncOperation();

            // Pop all pages off the navigation stack until we reach the root page (MainPage)
            await Navigation.PopToRootAsync();
        }

        // Example of an asynchronous operation
        private async Task SomeAsyncOperation()
        {
            // Simulate an asynchronous operation (e.g., saving data, logging, etc.)
            await Task.Delay(500); // Simulate a delay
        }
    }
}