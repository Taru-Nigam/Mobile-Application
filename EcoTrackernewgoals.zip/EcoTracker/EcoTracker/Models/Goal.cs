﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EcoTracker.Models
{
    public class Goal
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public string AdditionalDetails { get; set; }
        public DateTime? TargetDate { get; set; } // Nullable DateTime
        public int? DaysRemaining => TargetDate.HasValue ? (TargetDate.Value - DateTime.Now).Days : (int?)null; // Nullable DaysRemaining
        public double? Distance { get; set; }
        public double? Energy { get; set; }
        public double? Waste { get; set; }
        public bool IsCompleted { get; set; }
        public string ImagePath { get; set; } // Path to the image
    }
}
